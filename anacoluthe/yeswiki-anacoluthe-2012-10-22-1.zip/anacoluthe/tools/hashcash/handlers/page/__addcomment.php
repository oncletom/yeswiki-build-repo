<?php

if (!defined("WIKINI_VERSION"))
{
            die ("acc&egrave;s direct interdit");
}

$this->SetMessage("Commentaires desactives");
$this->Redirect($this->href());

?>
