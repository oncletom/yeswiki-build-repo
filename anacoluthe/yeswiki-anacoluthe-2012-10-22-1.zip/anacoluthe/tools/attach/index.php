<?php
// index.php
// Administration de l'extension : initialisations (tables, fichier de configuration) , information etc. : toutes
// op�rations r�serv�es � l'administrateur technique de Wikini.

// V�rification de s�curit�
if (!defined("TOOLS_MANAGER"))
{
        die ("acc&egrave;s direct interdit");
}

?>
