<?php

if (!defined("WIKINI_VERSION")) {
    die("acc&egrave;s direct interdit");
}

echo "\n".'<div class="page-break"></div>'."\n";
