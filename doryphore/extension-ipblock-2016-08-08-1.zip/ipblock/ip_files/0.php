<?php
//0-16777215
$ranges=Array(
"0" => array("16777215","ZZ"),
);
?>