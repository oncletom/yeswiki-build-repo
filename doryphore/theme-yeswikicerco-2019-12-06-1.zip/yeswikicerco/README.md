# yeswiki-theme-yeswiki
former default theme for yeswiki cercopitheque
