<?php
/**
 * Fichier de traduction en francais de l'extension AutoUpdate
 *
 *@package       autoupdate
 *@author        Florestan Bredow <florestan.bredow@supagro.fr>
 */

$GLOBALS['translations'] = array_merge(
    $GLOBALS['translations'],
    array(
        'E2M_EXPORT' => "Exporter en Markdown",
    )
);
