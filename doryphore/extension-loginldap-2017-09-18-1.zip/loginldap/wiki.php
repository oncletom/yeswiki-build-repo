<?php

if (!defined("WIKINI_VERSION")) {
    die("acc&egrave;s direct interdit");
}

$wikiClasses [] = 'ldap';
$wikiClassesContent [] = '';
