# yeswiki-theme-interface
Generic Yeswiki theme based on bootstrap but build with css variables
