<?php
if (!defined('WIKINI_VERSION')) {
    die("acc&egrave;s direct interdit");
}

ob_end_flush();
?>
  <script src="<?php echo computeBaseURL(true); ?>tools/templates/libs/vendor/jquery-3.3.1.min.js"></script>
  <script src="<?php echo computeBaseURL(true); ?>tools/templates/libs/vendor/bootstrap.min.js"></script>
</body>
</html>
