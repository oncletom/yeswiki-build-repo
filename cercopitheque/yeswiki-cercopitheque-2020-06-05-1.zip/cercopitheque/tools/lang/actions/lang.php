<?php

// TODO : a basculer dans __show.php
// Vérification de sécurité
if (!defined("WIKINI_VERSION"))
{
  die ("acc&egrave;s direct interdit");
}


?> 
