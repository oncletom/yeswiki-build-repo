<?php
// Administration

// Verification de securite
if (!defined("TOOLS_MANAGER")) {
    die("acc&egrave;s direct interdit");
}

$buffer->str('Le plugin "Templates" vous permet de gerer des template html et css pour votre design web.');
