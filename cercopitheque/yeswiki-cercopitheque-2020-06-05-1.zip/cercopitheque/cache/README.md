# Cache directory

The folder `cache` contains image thumbs and not permanent content.  
You can delete its content without risks (in theory).  
