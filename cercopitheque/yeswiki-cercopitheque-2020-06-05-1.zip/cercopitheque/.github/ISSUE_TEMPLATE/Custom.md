---
name:  Issue for YesWiki / demande pour YesWiki
about: Describe a bug or a new feature for YesWiki / Remonter un bogue ou une demande de fonctionnalité YesWiki

---

**Type of issue (keep only one) / Type de demande (ne garder qu'une ligne)**
New feature / Nouvelle fonctionnalité
Bug / Bogue

**Description**
Explain the bug or the feature / expliquer le bogue ou la fonctionnalité demandée

**Additionnal informations / Informations complémentaires**
- version of YesWiki / version de YesWiki
- url to see the problem or an example / url pour voir le probleme ou un exemple
- screenshot / capture d’écran
- logs
