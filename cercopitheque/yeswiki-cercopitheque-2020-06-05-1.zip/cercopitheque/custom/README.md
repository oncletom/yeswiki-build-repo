# Custom directory

The folder `custom` will be used for all your specific changes in yeswiki views.  
It is recommanded to copy existing content from `/templates`, `/themes`, and `/tools` as a start (you can rename them to have two choices or you can keep the existing name to replace default content).  
It contains three subfolders :  

- `custom/templates` : for custom templates
- `custom/themes` : for custom themes
- `custom/tools` : for custom extensions
