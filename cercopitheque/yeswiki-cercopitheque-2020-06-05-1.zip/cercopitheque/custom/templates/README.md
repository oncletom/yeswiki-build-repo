# Custom templates directory

The folder `custom/templates` is for your own custom templates.
