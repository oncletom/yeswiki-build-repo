# Custom themes directory

The folder `custom/themes` is for your own custom themes.
