# yeswiki-theme-margot
New default theme for YesWiki Doriphore
