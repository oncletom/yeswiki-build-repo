# yeswiki-extension-login-cas
Use CAS server authentification in YesWiki
